# Dashboard Comercial — PWA

## Instalar en iPhone

1. Abre Safari en tu iPhone
2. Ve a la URL de tu GitHub Pages (ej: `https://tuusuario.github.io/dashboard-ventas`)
3. Toca el botón **Compartir** (cuadrado con flecha ↑)
4. Toca **"Añadir a pantalla de inicio"**
5. Toca **Añadir**

La app aparecerá en tu pantalla de inicio como cualquier otra app.
